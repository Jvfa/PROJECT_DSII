package br.com.viladafolha.CadastroNinja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroNinjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
