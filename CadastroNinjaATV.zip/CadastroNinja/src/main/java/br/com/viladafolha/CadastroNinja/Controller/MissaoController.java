package br.com.viladafolha.CadastroNinja.Controller;

import br.com.viladafolha.CadastroNinja.Entity.MissaoEntity;
import br.com.viladafolha.CadastroNinja.Exception.ResponseGenericException;
import br.com.viladafolha.CadastroNinja.Service.MissaoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/missao")

public class MissaoController {
    @Autowired
    private MissaoService missaoService;

    @GetMapping("/missoes")
    public String Missoes(){
        return "Bem vindo ao sistema de missoes da Vila da Folha.";
    }

    //Cadastrar
    @PostMapping("/cadastrar")
    public ResponseEntity<Object> salvar(@Valid @RequestBody MissaoEntity missao){
        MissaoEntity resultado = missaoService.cadastrar(missao);
        return ResponseEntity.ok().body(ResponseGenericException.response(resultado));
    }

    //Listar
    @GetMapping("/listar")
    public List<MissaoEntity> listar(){
        return missaoService.listar();
    }

    //Pesquisar
    @GetMapping("/pesquisar/{id}")
    public ResponseEntity<Object> pesquisarMissao (@PathVariable Long id){
        Optional<MissaoEntity> resultado = missaoService.pesquisar(id);
        return ResponseEntity.ok().body(ResponseGenericException.response(resultado));
    }

    //Delete
    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<Object> deletar(@PathVariable Long id){
        HashMap<String, Object> resultado = missaoService.deleteCliente(id);
        return  ResponseEntity.ok().body(ResponseGenericException.response(resultado));
    }

    //ALTERAR
    @PutMapping("/alterar/{id}")
    public ResponseEntity<?> alterar(@PathVariable Long id, @RequestBody @Valid MissaoEntity missaoAlterado){
        return ResponseEntity.ok(missaoService.alterar(id,missaoAlterado));
    }
}
