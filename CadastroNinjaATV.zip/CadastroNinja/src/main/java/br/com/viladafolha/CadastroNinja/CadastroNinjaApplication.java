package br.com.viladafolha.CadastroNinja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroNinjaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroNinjaApplication.class, args);
	}

}
